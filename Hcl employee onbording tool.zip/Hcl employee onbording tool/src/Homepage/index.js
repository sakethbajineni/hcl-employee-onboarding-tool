import * as React from "react";
import Box from "@mui/material/Box";
import Stepper from "@mui/material/Stepper";
import Step from "@mui/material/Step";
import StepLabel from "@mui/material/StepLabel";
import StepContent from "@mui/material/StepContent";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import LinearProgress from "@mui/material/LinearProgress";
import Avatar from "@mui/material/Avatar";
import Cookies from "js-cookie";
import { useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import "./index.css";
import {
  Step1,
  Step2,
  Step3,
  Step4,
  Step5,
  Step6,
  Step7,
  Step8,
  Step9,
  Step10,
} from "./steps/step1";
import { useLocation } from "react-router-dom";

const steps = [
  {
    label: "Complete your profile",
    description: "Please fill all the necessary details",
    time: 5,
  },
  {
    label: "What we are,who we are and what we do",

    time: 5,
  },
  {
    label: "Team communication channels",

    time: 2,
  },
  {
    label: "How do we have fun",

    time: 2,
  },
  {
    label: "My timesheet",

    time: 2,
  },
  {
    label: "My Leaves",

    time: 2,
  },
  {
    label: "What are my benefits",

    time: 3,
  },
  {
    label: "Day one",

    time: 5,
  },
  {
    label: "F.A.Q",

    time: 2,
  },
  {
    label: "Help us to improve preboarding",

    time: 2,
  },
];

function LinearProgressWithLabel(props) {
  return (
    <Box sx={{ display: "flex", alignItems: "center" }}>
      <Box sx={{ width: "100%", mr: 1 }}>
        <LinearProgress variant="determinate" {...props} />
      </Box>
      <Box sx={{ minWidth: 35 }}>
        <Typography variant="body2" color="text.secondary">{`${Math.round(
          props.value
        )}%`}</Typography>
      </Box>
    </Box>
  );
}
export const Homepage = () => {
  const [activeStep, setActiveStep] = useState(0);
  const [progress, setProgress] = useState(0);
  const [userdeatils, setuser] = useState({
    id: 1,
    name: "",
    joiningdate: "2023-05-22",
    location: "Hyderabad",
    role: "Web Developer",
  });
  const [tasktime, setTime] = useState(30);
  const [showstep, setstep] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const [data, setData] = useState([]);
  const [data1, setData1] = useState([]);

  const handleNext = () => {
    // setActiveStep((prevActiveStep) => prevActiveStep + 1 );

    setstep(true);
  };
  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
    setTime((prev) => prev + steps[activeStep].time);
    setProgress((activeStep - 1) * 10);
  };
  const updateuser = (data) => {
    setuser((prevUserDetails) => {
      return {
        ...prevUserDetails,
        ...data,
      };
    });
  };

  // useEffect(() => {
  //   let data;
  //   async function fetchData() {
  //     const id = Cookies.get("id");
  //     const url = `http://localhost:8080/profile?userid=${location.state.userid}`;
  //     const options = {
  //       method: "GET",
  //       headers: {
  //         "Content-Type": "application/json",
  //       },
  //     };
  //     const responce = await fetch(url, options);
  //     data = await responce.json();

  //     updateuser(data);

  //   }
  //   fetchData();

  // }, []);
  useEffect(() => {
    fetch(`http://localhost:8080/profile?userid=${location.state.userid}`)
      .then((response) => response.json())
      .then((data) => setData(data))
      .catch((error) => console.error(error));
  }, []);
  useEffect(() => {
    fetch(`http://localhost:8080/newjoiners?userid=${location.state.userid}`)
      .then((response) => response.json())
      .then((data1) => setData1(data1))
      .catch((error) => console.error(error));
  }, []);
  const singout = () => {
    Cookies.remove("jwtToken");
    navigate("/");
  };

  function ByteToImage({ bytecode }) {
    return (
      <div>
        <img
          src={`data:image/jpeg;base64,${bytecode}`}
          width="70px"
          height="70px"
          className="rounded-full"
        />
      </div>
    );
  }
  console.log(data.photo, "image");
  // console.log(data1[0].photo, "imag");
  // console.log(data1[1].photo, "imag");

  var base64Image = "data:image/png;base64,{data.photo}";
  const updateuserdate = (data) => {
    const joiningDate = new Date(data);
    const currentDate = new Date();
    const differenceInMs = joiningDate.getTime() - currentDate.getTime();
    const differenceInDays = Math.ceil(differenceInMs / (1000 * 3600 * 24));
    return differenceInDays;
  };
  const newstep = () => {
    setstep(false);
  };
  const setactive = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
    setTime((prev) => prev - steps[activeStep].time);
    setProgress((activeStep + 1) * 10);
  };
  if (showstep) {
    switch (activeStep) {
      case 0:
        return (
          <Step1
            currentstep={newstep}
            setsteps={setactive}
            heading={steps[activeStep].label}
          />
        );

      case 1:
        return (
          <Step2
            currentstep={newstep}
            setsteps={setactive}
            heading={steps[activeStep].label}
          />
        );

      case 2:
        return (
          <Step3
            currentstep={newstep}
            setsteps={setactive}
            heading={steps[activeStep].label}
          />
        );

      case 3:
        return (
          <Step4
            currentstep={newstep}
            setsteps={setactive}
            heading={steps[activeStep].label}
          />
        );

      case 4:
        return (
          <Step5
            currentstep={newstep}
            setsteps={setactive}
            heading={steps[activeStep].label}
          />
        );

      case 5:
        return (
          <Step6
            currentstep={newstep}
            setsteps={setactive}
            heading={steps[activeStep].label}
          />
        );

      case 6:
        return (
          <Step7
            currentstep={newstep}
            setsteps={setactive}
            heading={steps[activeStep].label}
          />
        );

      case 7:
        return (
          <Step8
            currentstep={newstep}
            setsteps={setactive}
            heading={steps[activeStep].label}
          />
        );

      case 8:
        return (
          <Step9
            currentstep={newstep}
            setsteps={setactive}
            heading={steps[activeStep].label}
          />
        );
      case 9:
        return (
          <Step10
            currentstep={newstep}
            setsteps={setactive}
            heading={steps[activeStep].label}
          />
        );
      default:
        break;
    }
  }
  return (
    <>
      <div className="flex justify-center">
        <div className=" homePage w-5/6  border-2 border-neutral-800 ">
          <div className="flex justify-between p-2">
            <h1 className="text-blue-600 font-bold p-3">HCLTech</h1>
            <button
              type="button"
              className=" bg-blue-600 border-none rounded text-white px-3 "
              onClick={singout}
            >
              Sign out
            </button>
          </div>
          <div className="w-full">
            <div className="flex  w-full">
              <div className="w-1/2 m-2 bg-slate-200 text-center p-5">
                <p>
                  {data.fullname}, we can't wait to see you in
                  {updateuserdate(data.joining_date)} days
                </p>
              </div>
              <div className="w-1/2 m-2 bg-slate-200 text-center p-5 items-center flex flex-col">
                <p>Your preboarding progress now</p>
                <Box sx={{ width: "80%" }}>
                  <LinearProgressWithLabel value={progress} />
                </Box>
              </div>
            </div>
            <div className="flex w-full">
              <div>
                <div className="flex bg-slate-200  p-2 items-center flex-col ml-2">
                  {/* <Avatar src="/broken-image.jpg" /> */}
                  <ByteToImage bytecode={data.photo} />
                  <p>{data.fullname}</p>
                  <p>{data.designation}</p>
                  <br />
                  <p>Joining Location: {data.joining_location}</p>
                  <p>Joining Date: {data.joining_date}</p>
                  <p>Tower:{data.tower}</p>
                  <p>ODC:odc {}</p>
                  <button
                    type="button"
                    className="w-3/4 mb-2 mt-1 bg-slate-300  border-solid border-2 p-1 border-slate-700 shadow-slate-600 shadow-md rounded-lg"
                  >
                    Contact Manager
                  </button>
                  <button
                    type="button"
                    className="w-3/4 bg-slate-300  border-solid border-2 p-1 border-slate-700 shadow-slate-600 shadow-md rounded-lg"
                  >
                    Contact HR
                  </button>
                </div>
                <div className=" otherJoiners bg-slate-200  p-2  ml-2 mt-2">
                  <h1 className=" flex justify-center font-bold mt-3 ml-3">
                    Other new joiners
                  </h1>
                  <div className=" other flex justify-around my-4">
                    {data1 && data1[0] && (
                      <div className="flex items-center flex-col">
                        <Avatar src="/broken-image.jpg" />
                        {/* <ByteToImage bytecode={data1[0].photo} /> */}
                        <p>{data1[0].fullname}</p>
                        <p>{data1[0].designation}</p>
                        <button
                          type="button"
                          className="w-full bg-slate-300  border-solid border-2 p-1 border-slate-700 shadow-slate-600 shadow-md rounded-lg"
                        >
                          Contact
                        </button>
                      </div>
                    )}
                    {data1 && data1[1] && (
                      <div className="flex items-center flex-col">
                        <Avatar src="/broken-image.jpg" />
                        {/* <ByteToImage bytecode={data1[1].photo} /> */}
                        <p>{data1[1].fullname}</p>
                        <p>{data1[1].designation}</p>
                        <button
                          type="button"
                          className="w-full bg-slate-300  border-solid border-2 p-1 border-slate-700 shadow-slate-600 shadow-md rounded-lg"
                        >
                          Contact
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              </div>
              <div className=" verticalStepper w-10/12 m-2">
                <div className="flex justify-between">
                  <p>Suggested Roadmap</p>
                  <p>{steps.length - activeStep} Tasks to complete</p>
                  <p>It should take you upto {tasktime} mins</p>
                </div>
                <Box
                  sx={{ maxWidth: 900 }}
                  className="mt-4 p-4 py-8  bg-slate-200"
                >
                  <Stepper activeStep={activeStep} orientation="vertical">
                    {steps.map((step, index) => (
                      <Step key={step.label}>
                        <StepLabel
                          optional={
                            index === 9 ? (
                              <Typography variant="caption">
                                Last step
                              </Typography>
                            ) : null
                          }
                        >
                          <div className=" flex justify-between">
                            <p>{step.label}</p>
                            <p>{step.time} min</p>
                          </div>
                        </StepLabel>
                        <StepContent>
                          <Typography>{step.description}</Typography>
                          <Box sx={{ mb: 2 }}>
                            <div>
                              <Button
                                onClick={handleBack}
                                disabled={activeStep === 0}
                                sx={{ mt: 1, mr: 1 }}
                              >
                                Back
                              </Button>
                              <Button
                                variant="contained"
                                onClick={handleNext}
                                sx={{ mt: 1, mr: 1 }}
                              >
                                {index === steps.length - 1
                                  ? "Finish"
                                  : "Continue"}
                              </Button>
                            </div>
                          </Box>
                        </StepContent>
                      </Step>
                    ))}
                  </Stepper>
                </Box>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};
